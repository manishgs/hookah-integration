<?php namespace App\Services;

/**
 * Class Services
 * @package App\Services
 */
class Services
{

}
