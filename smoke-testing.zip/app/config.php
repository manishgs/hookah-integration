<?php
return [
    'view_path' => '../app/Views'
];
