<?php echo view('layout/header');?>
<div class="page-header">
    <a class="pull-right" href="<?php echo url('admin/logout');?>">Logout</a>
    <h1>Dashboard</h1>
</div>
<p class="lead">Admin dashboard</p>
<?php echo view('layout/footer');?>
