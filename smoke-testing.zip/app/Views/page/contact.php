<?php echo view('layout/header');?>
<?php echo view('layout/menu');?>
<div class="page-header">
    <h1>Contact</h1>
</div>
<p class="lead">Contact Page</p>
<?php echo view('layout/footer');?>
