<?php echo view('layout/header');?>
<?php echo view('layout/menu');?>
<div class="page-header">
    <h1>Welcome</h1>
</div>
<p class="lead">Home Page</p>
<?php echo view('layout/footer');?>
