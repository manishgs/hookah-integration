<?php echo view('layout/header');?>
<?php echo view('layout/menu');?>
<div class="page-header">
    <h1>About</h1>
</div>
<p class="lead">About Page</p>
<?php echo view('layout/footer');?>
