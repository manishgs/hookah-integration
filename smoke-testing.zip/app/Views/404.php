<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Page not found</title>
</head>
<body>
    <div style="text-align: center">
        <h1>404</h1>
        <p>Page not found</p>
    </div>
</body>
</html>
