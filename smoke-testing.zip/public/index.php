<?php
session_start();
/*
 * Composer Autoload
 */
require '../vendor/autoload.php';

/*
 * Bootstrap application
 */
require '../bootstrap.php';

